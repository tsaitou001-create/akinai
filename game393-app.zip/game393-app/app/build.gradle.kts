plugins {
    id("com.android.application")
}

android {
    // 署名を固定する(上書きインストールできるように、毎回同じ鍵で署名する)
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    namespace = "com.example.game393"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.game393"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
