package com.example.game393;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

/** game393.html（assets に入れた HTML）を、アプリの中の WebView で表示する */
public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // セーブ（localStorage）に必要
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false); // 音を鳴らすため
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/game393.html");
        setContentView(web);
    }

    @Override
    public void onBackPressed() {
        // 戻るキーで、ゲームの中の戻る操作を先に行う（ページ内の履歴がなければ終了）
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }
}
